void atraso(int x) {
    int j, k;
    int l;
    for (l=0;l<x;l++){
    for (j = 0; j < 41; j++) {
        for (k = 0; k < 3; k++);
    }}





}
